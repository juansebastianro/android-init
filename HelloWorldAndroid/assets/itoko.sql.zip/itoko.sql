-- phpMyAdmin SQL Dump
-- version 2.11.4
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 14-02-2013 a las 22:21:39
-- Versión del servidor: 5.0.51
-- Versión de PHP: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Base de datos: `itoko`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `articulo`
--

DROP TABLE IF EXISTS `articulo`;
CREATE TABLE IF NOT EXISTS `articulo` (
  `articulo_id` int(11) NOT NULL auto_increment,
  `categoria_id` int(11) NOT NULL,
  `titulo` varchar(250) collate utf8_spanish_ci NOT NULL,
  `descripcion` text collate utf8_spanish_ci NOT NULL,
  `imagen` varchar(100) collate utf8_spanish_ci NOT NULL,
  `costo` decimal(10,2) default NULL,
  `precio` decimal(10,2) default NULL,
  `create_time` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`articulo_id`),
  KEY `categoria_id` (`categoria_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=6 ;

--
-- Volcar la base de datos para la tabla `articulo`
--

INSERT INTO `articulo` (`articulo_id`, `categoria_id`, `titulo`, `descripcion`, `imagen`, `costo`, `precio`, `create_time`) VALUES
(1, 2, 'Rol A', 'Este es el rol tipo A', '1.jpg', NULL, NULL, '2012-11-06 22:44:42'),
(2, 2, 'Rol B', 'este es el rico rol tipo B', '', NULL, NULL, '2012-11-06 22:44:42'),
(3, 2, 'Rol C', 'Este es el rol C', '2.jpg', NULL, NULL, '2012-11-11 16:14:11'),
(4, 2, 'Bebida 1', 'esta es la bedida 1', '', NULL, NULL, '2012-11-11 16:15:07'),
(5, 2, 'Te Loco', 'este es el te loco', 'tea1.jpg', NULL, NULL, '2012-11-11 16:15:07');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `articulo_ingrediente`
--

DROP TABLE IF EXISTS `articulo_ingrediente`;
CREATE TABLE IF NOT EXISTS `articulo_ingrediente` (
  `ai_id` int(11) NOT NULL,
  `articulo_id` int(11) NOT NULL,
  `ingrediente_id` int(11) NOT NULL,
  PRIMARY KEY  (`ai_id`),
  KEY `articulo_id` (`articulo_id`,`ingrediente_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcar la base de datos para la tabla `articulo_ingrediente`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categoria`
--

DROP TABLE IF EXISTS `categoria`;
CREATE TABLE IF NOT EXISTS `categoria` (
  `categoria_id` int(11) NOT NULL auto_increment,
  `categoria` varchar(250) collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`categoria_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `categoria`
--

INSERT INTO `categoria` (`categoria_id`, `categoria`) VALUES
(1, 'Noticias'),
(2, 'Menu');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

DROP TABLE IF EXISTS `cliente`;
CREATE TABLE IF NOT EXISTS `cliente` (
  `cliente_id` int(11) NOT NULL auto_increment,
  `cliente` varchar(250) collate utf8_spanish_ci NOT NULL,
  `email` varchar(250) collate utf8_spanish_ci NOT NULL,
  `direccion` varchar(500) collate utf8_spanish_ci NOT NULL,
  `telefono` varchar(100) collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`cliente_id`),
  KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `cliente`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ingrediente`
--

DROP TABLE IF EXISTS `ingrediente`;
CREATE TABLE IF NOT EXISTS `ingrediente` (
  `ingrediente_id` int(11) NOT NULL auto_increment,
  `ingrediente` varchar(250) collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`ingrediente_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `ingrediente`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `menu`
--

DROP TABLE IF EXISTS `menu`;
CREATE TABLE IF NOT EXISTS `menu` (
  `menu_id` int(11) NOT NULL auto_increment,
  `menu` varchar(250) collate utf8_spanish_ci NOT NULL,
  `descripcion` varchar(250) collate utf8_spanish_ci NOT NULL,
  `menu_tipo_id` int(11) NOT NULL,
  `costo` decimal(10,2) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `imagen` varchar(100) collate utf8_spanish_ci NOT NULL,
  `create_time` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `multiple` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`menu_id`),
  KEY `menu_tipo_id` (`menu_tipo_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=11 ;

--
-- Volcar la base de datos para la tabla `menu`
--

INSERT INTO `menu` (`menu_id`, `menu`, `descripcion`, `menu_tipo_id`, `costo`, `precio`, `imagen`, `create_time`, `multiple`) VALUES
(1, 'Menu 1', 'Disfruta el menu 1', 1, 70.00, 120.00, '1.jpg', '2012-11-05 21:15:08', 0),
(2, 'Menu 2', 'Disfruta el menu 2', 1, 100.00, 180.00, '2.jpg', '2012-11-05 21:15:08', 1),
(3, 'Menu 3', 'Disfruta el menu 3', 1, 50.00, 100.00, '3.jpg', '2012-11-05 21:16:02', 0),
(4, 'Menu 4', 'Disfruta el menu 4', 1, 40.00, 80.00, '4.jpg', '2012-11-05 21:16:02', 1),
(5, 'Menu 5', 'Disfruta el menu 5', 1, 70.00, 120.00, '1.jpg', '2012-11-05 21:15:08', 1),
(6, 'Menu 6', 'Disfruta el menu 6', 1, 100.00, 180.00, '2.jpg', '2012-11-05 21:15:08', 0),
(7, 'Menu 7', 'Disfruta el menu 7', 1, 50.00, 100.00, '3.jpg', '2012-11-05 21:16:02', 1),
(8, 'Menu 8', 'este es el menu 8 que tiene varias cosas', 2, 90.00, 89.00, 'ensalada1.jpg', '2012-11-11 17:43:03', 0),
(9, 'Menu 9', 'Este es el menu # 9 de ensaladas', 2, 80.00, 90.00, 'ensalada2.jpg', '2012-11-11 17:45:04', 0),
(10, 'Tea 1', 'este es el primer tea', 3, 88.00, 90.00, 'tea1.jpg', '2012-11-11 17:46:57', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `menu_articulo`
--

DROP TABLE IF EXISTS `menu_articulo`;
CREATE TABLE IF NOT EXISTS `menu_articulo` (
  `ma_id` int(11) NOT NULL auto_increment,
  `menu_id` int(11) NOT NULL,
  `articulo_id` int(11) NOT NULL,
  PRIMARY KEY  (`ma_id`),
  KEY `menu_id` (`menu_id`,`articulo_id`),
  KEY `articulo_id` (`articulo_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `menu_articulo`
--

INSERT INTO `menu_articulo` (`ma_id`, `menu_id`, `articulo_id`) VALUES
(1, 2, 1),
(2, 2, 3),
(3, 2, 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `menu_tipo`
--

DROP TABLE IF EXISTS `menu_tipo`;
CREATE TABLE IF NOT EXISTS `menu_tipo` (
  `menu_tipo_id` int(11) NOT NULL auto_increment,
  `menu_tipo` varchar(250) collate utf8_spanish_ci NOT NULL,
  `menu_tipo_des` varchar(250) collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`menu_tipo_id`),
  KEY `menu_tipo` (`menu_tipo`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `menu_tipo`
--

INSERT INTO `menu_tipo` (`menu_tipo_id`, `menu_tipo`, `menu_tipo_des`) VALUES
(1, 'sushi', 'Sushi'),
(2, 'ensaladas', 'Ensalada'),
(3, 'bebidas', 'Bebidas');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `orden`
--

DROP TABLE IF EXISTS `orden`;
CREATE TABLE IF NOT EXISTS `orden` (
  `orden_id` int(11) NOT NULL auto_increment,
  `cliente_id` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `observacion` varchar(500) collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`orden_id`),
  KEY `cliente_id` (`cliente_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `orden`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `orden_det`
--

DROP TABLE IF EXISTS `orden_det`;
CREATE TABLE IF NOT EXISTS `orden_det` (
  `orden_det_id` int(11) NOT NULL auto_increment,
  `orden_id` int(11) NOT NULL,
  `articulo_id` int(11) NOT NULL,
  `cantidad` int(4) NOT NULL,
  PRIMARY KEY  (`orden_det_id`),
  KEY `orden_id` (`orden_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `orden_det`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

DROP TABLE IF EXISTS `usuario`;
CREATE TABLE IF NOT EXISTS `usuario` (
  `usuario_id` int(11) NOT NULL auto_increment,
  `email` varchar(250) collate utf8_spanish_ci NOT NULL,
  `password` varchar(250) collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`usuario_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `usuario`
--


--
-- Filtros para las tablas descargadas (dump)
--

--
-- Filtros para la tabla `articulo`
--
ALTER TABLE `articulo`
  ADD CONSTRAINT `articulo_ibfk_1` FOREIGN KEY (`categoria_id`) REFERENCES `categoria` (`categoria_id`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `menu`
--
ALTER TABLE `menu`
  ADD CONSTRAINT `menu_ibfk_1` FOREIGN KEY (`menu_tipo_id`) REFERENCES `menu_tipo` (`menu_tipo_id`);

--
-- Filtros para la tabla `menu_articulo`
--
ALTER TABLE `menu_articulo`
  ADD CONSTRAINT `menu_articulo_ibfk_1` FOREIGN KEY (`menu_id`) REFERENCES `menu` (`menu_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `menu_articulo_ibfk_2` FOREIGN KEY (`articulo_id`) REFERENCES `articulo` (`articulo_id`) ON UPDATE CASCADE;
